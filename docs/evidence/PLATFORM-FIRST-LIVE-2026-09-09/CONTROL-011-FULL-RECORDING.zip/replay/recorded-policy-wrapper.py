"""Local verification only: apply the recorded partial-completion policy omitted by stock replay's prefix allowlist.
No production/application source change; no fabricated response; original replay network guard remains.
"""
from pathlib import Path
import importlib.util,json
r=Path(__file__).parent;spec=importlib.util.spec_from_file_location('recorded_worker_runner',r.parent/'ac-local/apps/api/scripts/replay_generation.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner);original=runner.run
async def recorded_policy(args):
 from app.core.config import settings
 d=json.loads(args.recording.read_text());snap=next(e['payload'] for e in d['document_provenance'] if e['event_type']=='generation_replay_inputs' and e['payload']['job_id']==args.job_id)
 settings.PARTIAL_COMPLETION_ENABLED=snap['profile']['settings']['PARTIAL_COMPLETION_ENABLED']
 return await original(args)
runner.run=recorded_policy
raise SystemExit(runner.main())
